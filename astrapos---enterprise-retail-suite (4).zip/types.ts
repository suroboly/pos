
export enum UserRole {
  ADMIN = 'ADMIN',
  STAFF = 'STAFF'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  username: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  stockQuantity: number;
  lowStockLevel: number;
  barcode: string;
  image?: string;
}

export interface CartItem extends Product {
  quantity: number;
  itemDiscount: number;
}

export interface Sale {
  id: string;
  timestamp: number;
  items: CartItem[];
  subtotal: number;
  discount: number;
  vat: number;
  total: number;
  paidAmount: number;
  changeAmount: number;
  cashierId: string;
  customerId?: string;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
}

export interface Expense {
  id: string;
  type: 'STAFF' | 'UTILITY' | 'OTHER';
  amount: number;
  date: string;
  description: string;
}

export interface SystemSettings {
  shopName: string;
  address: string;
  phone: string;
  logoUrl?: string;
  vatEnabled: boolean;
  vatPercentage: number;
}
