
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Product, Sale, User, UserRole, Customer, Expense, SystemSettings } from './types';

interface AppState {
  currentUser: User | null;
  products: Product[];
  sales: Sale[];
  customers: Customer[];
  expenses: Expense[];
  settings: SystemSettings;
  setCurrentUser: (user: User | null) => void;
  addProduct: (p: Product) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;
  addSale: (s: Sale) => void;
  addCustomer: (c: Customer) => void;
  addExpense: (e: Expense) => void;
  deleteExpense: (id: string) => void;
  updateSettings: (s: SystemSettings) => void;
}

const DEFAULT_SETTINGS: SystemSettings = {
  shopName: "ASTRA SUPERMART",
  address: "123 Business Avenue, Suite 400",
  phone: "+880 1700-000000",
  vatEnabled: true,
  vatPercentage: 5,
};

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('astra_products');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Premium Coffee 500g', category: 'Beverages', costPrice: 400, sellingPrice: 550, stockQuantity: 45, lowStockLevel: 10, barcode: '1001', image: 'https://picsum.photos/seed/coffee/200' },
      { id: '2', name: 'Organic Milk 1L', category: 'Dairy', costPrice: 70, sellingPrice: 90, stockQuantity: 120, lowStockLevel: 20, barcode: '1002', image: 'https://picsum.photos/seed/milk/200' },
    ];
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('astra_sales');
    return saved ? JSON.parse(saved) : [];
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('astra_customers');
    return saved ? JSON.parse(saved) : [];
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('astra_expenses');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<SystemSettings>(() => {
    const saved = localStorage.getItem('astra_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  useEffect(() => localStorage.setItem('astra_products', JSON.stringify(products)), [products]);
  useEffect(() => localStorage.setItem('astra_sales', JSON.stringify(sales)), [sales]);
  useEffect(() => localStorage.setItem('astra_customers', JSON.stringify(customers)), [customers]);
  useEffect(() => localStorage.setItem('astra_expenses', JSON.stringify(expenses)), [expenses]);
  useEffect(() => localStorage.setItem('astra_settings', JSON.stringify(settings)), [settings]);

  const addProduct = (p: Product) => setProducts(prev => [...prev, p]);
  const updateProduct = (p: Product) => setProducts(prev => prev.map(item => item.id === p.id ? p : item));
  const deleteProduct = (id: string) => setProducts(prev => prev.filter(p => p.id !== id));
  
  const addSale = (s: Sale) => {
    setSales(prev => [...prev, s]);
    setProducts(prev => prev.map(p => {
      const soldItem = s.items.find(si => si.id === p.id);
      if (soldItem) return { ...p, stockQuantity: p.stockQuantity - soldItem.quantity };
      return p;
    }));
  };

  const addCustomer = (c: Customer) => setCustomers(prev => [...prev, c]);
  const addExpense = (e: Expense) => setExpenses(prev => [...prev, e]);
  const deleteExpense = (id: string) => setExpenses(prev => prev.filter(x => x.id !== id));
  const updateSettings = (s: SystemSettings) => setSettings(s);

  return (
    <AppContext.Provider value={{
      currentUser, setCurrentUser,
      products, addProduct, updateProduct, deleteProduct,
      sales, addSale,
      customers, addCustomer,
      expenses, addExpense, deleteExpense,
      settings, updateSettings
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
