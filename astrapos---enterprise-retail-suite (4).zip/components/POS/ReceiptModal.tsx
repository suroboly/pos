
import React, { useEffect, useRef } from 'react';
import { Sale } from '../../types';
import { useApp } from '../../store';

interface ReceiptModalProps {
  sale: Sale;
  onClose: () => void;
}

const ReceiptModal: React.FC<ReceiptModalProps> = ({ sale, onClose }) => {
  const { settings, currentUser } = useApp();
  const receiptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleReceiptKeyDown = (e: KeyboardEvent) => {
      // Close (Esc)
      if (e.key === 'Escape') {
        onClose();
      }
      // Print (Alt+P)
      if (e.altKey && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        window.print();
      }
    };

    window.addEventListener('keydown', handleReceiptKeyDown);
    
    // Auto-print on open
    const timer = setTimeout(() => {
      window.print();
    }, 500);

    return () => {
      window.removeEventListener('keydown', handleReceiptKeyDown);
      clearTimeout(timer);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center no-print">
      <div className="bg-white rounded-[3rem] shadow-2xl max-w-sm w-full p-10 relative border border-gray-100 animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="relative group absolute top-6 right-6 w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:text-red-500 transition-all active:scale-90"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
          <span className="absolute -bottom-2 -right-2 bg-gray-900 text-white px-2 rounded text-[7px] font-black">ESC</span>
        </button>

        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-5">
            <i className="fa-solid fa-check text-green-500 text-4xl"></i>
          </div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">পেমেন্ট সফল!</h2>
          <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mt-2">অটো-প্রিন্ট হচ্ছে...</p>
        </div>

        {/* Visual Preview */}
        <div 
          ref={receiptRef}
          className="bg-gray-50 rounded-[2rem] p-6 border-2 border-dashed border-gray-100 text-[11px] font-mono overflow-y-auto max-h-[350px] shadow-inner"
        >
          <div className="text-center mb-6 border-b border-dashed pb-6">
            <h1 className="font-black text-sm uppercase mb-1">{settings.shopName}</h1>
            <p className="text-[9px] text-gray-400 leading-tight">{settings.address}</p>
          </div>

          <div className="space-y-3 mb-6">
            {sale.items.map(item => (
              <div key={item.id} className="flex justify-between gap-4">
                <div className="flex-1 truncate">
                  <p className="font-bold text-gray-700">{item.name}</p>
                  <p className="text-[8px] text-gray-400">{item.quantity} x ৳{item.sellingPrice.toFixed(0)}</p>
                </div>
                <span className="whitespace-nowrap font-black text-gray-800">৳{(item.sellingPrice * item.quantity).toFixed(0)}</span>
              </div>
            ))}
          </div>

          <div className="border-t border-dashed pt-4 space-y-2 font-black">
            <div className="flex justify-between text-base pt-2 text-blue-600 border-t border-dashed mt-2">
              <span>TOTAL</span>
              <span>৳{sale.total.toFixed(0)}</span>
            </div>
          </div>
        </div>

        <div className="mt-8 flex gap-3">
          <button 
            onClick={() => window.print()}
            className="relative group flex-1 bg-gray-50 hover:bg-gray-100 text-gray-500 font-black py-4 rounded-2xl transition-all flex items-center justify-center gap-2 active:scale-95 border border-gray-100"
          >
            <i className="fa-solid fa-redo text-xs"></i>
            Reprint
            <span className="absolute -top-2 -right-2 bg-white text-gray-400 border border-gray-100 px-1 rounded text-[7px] font-black">ALT+P</span>
          </button>
          <button 
            onClick={onClose}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl transition-all shadow-xl active:scale-95"
          >
            Next Sale [ESC]
          </button>
        </div>
      </div>

      {/* Actual Print Content for Thermal Printer */}
      <div className="print-only fixed top-0 left-0 w-[80mm] p-6 bg-white text-black font-mono text-[14px]">
        <div className="text-center mb-6">
          <h1 className="font-black text-xl mb-1">{settings.shopName}</h1>
          <p className="text-[12px]">{settings.address}</p>
        </div>
        <table className="w-full mb-3">
          <tbody>
            {sale.items.map(item => (
              <tr key={item.id} className="text-[12px]">
                <td className="py-1">{item.name} x{item.quantity}</td>
                <td className="text-right py-1">৳{(item.sellingPrice * item.quantity).toFixed(0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="border-t border-black border-dashed pt-3 font-black text-lg flex justify-between">
          <span>Total</span><span>৳{sale.total.toFixed(0)}</span>
        </div>
        <div className="text-center mt-8 pt-5 border-t border-black border-dashed">
          <p className="font-black">ধন্যবাদ!</p>
        </div>
      </div>
    </div>
  );
};

export default ReceiptModal;
