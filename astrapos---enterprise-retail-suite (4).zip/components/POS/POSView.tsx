
import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../store';
import { Product, CartItem, UserRole } from '../../types';
import { beepService } from '../../services/audio';
import ReceiptModal from './ReceiptModal';

interface POSViewProps {
  onGoAdmin: () => void;
}

const POSView: React.FC<POSViewProps> = ({ onGoAdmin }) => {
  const { products, currentUser, addSale, settings, customers, addCustomer } = useApp();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [barcodeBuffer, setBarcodeBuffer] = useState('');
  const [paidAmount, setPaidAmount] = useState<string>('');
  const [selectedCustomer, setSelectedCustomer] = useState<string>('Guest');
  const [lastSale, setLastSale] = useState<any>(null);
  const [showDrawerOpenMsg, setShowDrawerOpenMsg] = useState(false);
  
  // New Customer Modal States
  const [isAddingCustomer, setIsAddingCustomer] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ name: '', mobile: '' });
  
  const searchInputRef = useRef<HTMLInputElement>(null);
  const paidInputRef = useRef<HTMLInputElement>(null);
  const barcodeTimeoutRef = useRef<number | null>(null);

  const calculateSubtotal = () => cart.reduce((sum, item) => sum + (item.sellingPrice * item.quantity), 0);
  const vatAmount = settings.vatEnabled ? (calculateSubtotal() * settings.vatPercentage / 100) : 0;
  const totalToPay = calculateSubtotal() + vatAmount;
  const changeToReturn = Math.max(0, Number(paidAmount) - totalToPay);
  const isPaymentValid = Number(paidAmount) >= totalToPay && totalToPay > 0;

  const confirmTransaction = () => {
    if (!isPaymentValid) return;
    beepService.playPaymentSuccess();
    beepService.playCashDrawerOpen();
    setShowDrawerOpenMsg(true);
    setTimeout(() => setShowDrawerOpenMsg(false), 2000);

    const sale = {
      id: 'INV-' + Date.now().toString(36).toUpperCase().substr(-6),
      timestamp: Date.now(),
      items: [...cart],
      subtotal: calculateSubtotal(),
      discount: 0,
      vat: vatAmount,
      total: totalToPay,
      paidAmount: Number(paidAmount),
      changeAmount: changeToReturn,
      cashierId: currentUser?.name || 'Staff',
      customerId: selectedCustomer
    };

    addSale(sale);
    setLastSale(sale);
    setCart([]);
    setPaidAmount('');
    setSelectedCustomer('Guest');
  };

  const handleQuickAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name || !newCustomer.mobile) return;
    
    const id = Date.now().toString();
    addCustomer({ id, ...newCustomer });
    setSelectedCustomer(newCustomer.name);
    setNewCustomer({ name: '', mobile: '' });
    setIsAddingCustomer(false);
    beepService.playScanSuccess();
  };

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (isAddingCustomer) return;

      // Handle Shortcuts
      if (e.key === 'F1') { e.preventDefault(); searchInputRef.current?.focus(); return; }
      if (e.key === 'F2') { e.preventDefault(); paidInputRef.current?.focus(); return; }
      if (e.key === 'F12') { e.preventDefault(); if (isPaymentValid) confirmTransaction(); return; }
      if (e.key === 'F4') {
        e.preventDefault();
        if (cart.length > 0 && confirm("পুরো কার্ট ডিলিট করতে চান?")) {
          setCart([]); setPaidAmount(''); beepService.playRemove();
        }
        return;
      }
      if (e.altKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        if (currentUser?.role === UserRole.ADMIN) onGoAdmin();
        return;
      }
      if (e.altKey && e.key.toLowerCase() === 'c') {
        e.preventDefault();
        setIsAddingCustomer(true);
        return;
      }

      // Handle Enter (Barcode Finished or Payment Confirmation)
      if (e.key === 'Enter') {
        if (barcodeBuffer.length > 2) {
          const product = products.find(p => p.barcode === barcodeBuffer);
          if (product) {
            addToCart(product, true);
          } else {
            beepService.playError();
          }
          setBarcodeBuffer('');
          e.preventDefault();
        } else if (isPaymentValid && document.activeElement === paidInputRef.current) {
          confirmTransaction();
          e.preventDefault();
        }
        return;
      }

      // Capture Barcode Input (only if not typing in an input field)
      if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        if (e.key.length === 1) { // Single alphanumeric char
          setBarcodeBuffer(prev => prev + e.key);
          
          // Clear buffer if there is a long pause (500ms)
          if (barcodeTimeoutRef.current) window.clearTimeout(barcodeTimeoutRef.current);
          barcodeTimeoutRef.current = window.setTimeout(() => {
            setBarcodeBuffer('');
          }, 500);
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [cart, isPaymentValid, currentUser, selectedCustomer, barcodeBuffer, products, isAddingCustomer]);

  const addToCart = (product: Product, isScan: boolean = false) => {
    if (isScan) beepService.playScanSuccess();
    else beepService.playSoftBeep();
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1, itemDiscount: 0 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    beepService.playSoftBeep();
    setCart(prev => prev.map(item => (item.id === id) ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));
  };

  const removeFromCart = (id: string) => {
    beepService.playRemove();
    setCart(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="flex flex-col h-screen bg-[#f1f5f9] overflow-hidden select-none font-sans" onClick={() => beepService.init()}>
      {showDrawerOpenMsg && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-8 py-4 rounded-full shadow-2xl z-[200] flex items-center gap-3 animate-bounce border border-white/10">
          <i className="fa-solid fa-vault text-yellow-400 text-xl"></i>
          <span className="font-black uppercase text-xs tracking-[0.2em]">Drawer Opened</span>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b h-16 px-6 flex justify-between items-center shadow-sm z-20">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <i className="fa-solid fa-shop text-white text-lg"></i>
          </div>
          <div>
            <h1 className="font-black text-gray-800 text-xs uppercase tracking-tighter">{settings.shopName}</h1>
            <p className="text-[8px] text-gray-400 font-black uppercase tracking-widest">Operator: {currentUser?.name}</p>
          </div>
        </div>
        <div className="flex-1 max-w-xl mx-12">
          <div className="relative group">
            <i className="fa-solid fa-search absolute left-5 top-1/2 -translate-y-1/2 text-gray-300"></i>
            <input 
              ref={searchInputRef}
              type="text" 
              placeholder="F1: বারকোড স্ক্যান বা পণ্য খুঁজুন..." 
              className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-3 pl-12 pr-4 outline-none font-bold text-gray-700 text-sm transition-all shadow-inner"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-black bg-white px-2 py-0.5 rounded-lg text-blue-500 border border-blue-100 shadow-sm">F1</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-gray-50 px-4 py-1.5 rounded-xl border border-gray-100 shadow-sm">
             <i className="fa-solid fa-user-tag text-blue-500 text-[10px]"></i>
             <select 
              className="bg-transparent text-[10px] font-black uppercase outline-none cursor-pointer appearance-none min-w-[100px]"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
             >
                <option value="Guest">Walk-in Guest</option>
                {customers.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
             </select>
             <button 
               onClick={() => setIsAddingCustomer(true)}
               className="ml-2 w-7 h-7 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all active:scale-90"
               title="অ্যাড কাস্টমার (ALT+C)"
             >
               <i className="fa-solid fa-plus text-[10px]"></i>
             </button>
          </div>
          {currentUser?.role === UserRole.ADMIN && (
            <button onClick={onGoAdmin} className="relative group w-11 h-11 rounded-2xl border border-gray-100 shadow-sm text-gray-400 hover:text-blue-600 hover:border-blue-200 flex items-center justify-center transition-all active:scale-90">
              <i className="fa-solid fa-sliders text-lg"></i>
              <span className="absolute -bottom-1 -right-1 bg-white border border-gray-100 px-1 rounded text-[7px] font-black text-gray-400">ALT+A</span>
            </button>
          )}
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Products Grid */}
        <main className="flex-1 p-6 overflow-y-auto custom-scrollbar bg-gray-50/50">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.barcode.includes(searchQuery)).map(p => (
              <button key={p.id} onClick={() => addToCart(p)} className="bg-white rounded-[2.5rem] p-4 shadow-sm border border-gray-100 hover:border-blue-400 hover:shadow-xl transition-all text-left group active:scale-95">
                <div className="aspect-square bg-gray-50 rounded-[1.8rem] mb-3 overflow-hidden border"><img src={p.image || 'https://via.placeholder.com/150'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" /></div>
                <h3 className="font-bold text-gray-800 text-[11px] line-clamp-1 group-hover:text-blue-600 px-1">{p.name}</h3>
                <div className="flex justify-between items-center mt-3 px-1">
                   <span className="text-blue-600 font-black text-md">৳{p.sellingPrice.toFixed(0)}</span>
                   <span className="text-[9px] text-gray-400 font-bold bg-gray-50 px-2 py-0.5 rounded-full border">STOCK: {p.stockQuantity}</span>
                </div>
              </button>
            ))}
          </div>
        </main>

        {/* Shopping Cart Sidebar */}
        <aside className="w-[440px] bg-white border-l shadow-2xl flex flex-col z-10">
          <div className="p-5 border-b flex justify-between items-center bg-gray-50/50">
            <h2 className="font-black text-gray-800 text-[10px] tracking-widest uppercase flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-600"></div> SHOPPING CART
            </h2>
            <div className="flex items-center gap-3">
              <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-[9px] font-black">{cart.length} ITEMS</span>
              <button onClick={() => {setCart([]); setPaidAmount(''); beepService.playRemove();}} className="relative group text-gray-300 hover:text-red-500 transition-colors ml-2">
                <i className="fa-solid fa-trash-can text-sm"></i>
                <span className="absolute -top-1 -right-6 bg-red-50 text-red-400 border border-red-100 px-1 rounded text-[7px] font-black">F4</span>
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center opacity-30">
                <i className="fa-solid fa-cart-shopping text-7xl mb-4 text-gray-200"></i>
                <p className="font-black text-[10px] uppercase tracking-[0.4em]">Empty Cart</p>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="flex gap-4 p-4 rounded-3xl bg-gray-50/60 border border-transparent hover:border-blue-100 hover:bg-white hover:shadow-lg transition-all group">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden border bg-white flex-shrink-0 shadow-sm"><img src={item.image} className="w-full h-full object-cover" /></div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-gray-800 text-[11px] truncate mb-1">{item.name}</h4>
                    <div className="flex items-center justify-between">
                      <p className="text-blue-600 font-black text-xs">৳{(item.sellingPrice * item.quantity).toFixed(0)}</p>
                      <div className="flex items-center gap-3">
                         <div className="flex items-center bg-white rounded-xl border border-gray-100 shadow-sm px-1 py-0.5">
                            <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg">-</button>
                            <span className="w-8 text-center text-[11px] font-black">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-green-500 hover:bg-green-50 rounded-lg">+</button>
                         </div>
                         <button onClick={() => removeFromCart(item.id)} className="w-8 h-8 text-gray-300 hover:text-red-500 transition-all"><i className="fa-solid fa-circle-xmark text-lg"></i></button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Payment Section */}
          <div className="bg-[#0f172a] p-8 rounded-t-[3rem] shadow-[0_-20px_50px_-15px_rgba(0,0,0,0.3)]">
             <div className="flex justify-between items-end mb-8 border-b border-white/5 pb-6">
                <div>
                   <span className="text-white/40 font-black text-[10px] uppercase tracking-[0.2em] mb-1 block">Total Payable</span>
                   {settings.vatEnabled && <span className="text-blue-400/60 text-[8px] font-bold">INCL. {settings.vatPercentage}% VAT (৳{vatAmount.toFixed(0)})</span>}
                </div>
                <div className="text-right">
                   <div className="text-5xl font-black text-blue-500 tracking-tighter"><span className="text-3xl mr-1 font-normal opacity-40">৳</span>{totalToPay.toFixed(0)}</div>
                </div>
             </div>

             <div className="space-y-6">
                <div className="relative group">
                   <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center gap-3 pointer-events-none">
                      <span className="text-4xl font-black text-white/5 group-focus-within:text-blue-500 transition-colors">৳</span>
                   </div>
                   <input 
                      ref={paidInputRef}
                      type="number" 
                      placeholder="CASH RECEIVED (F2)"
                      className="w-full bg-white/5 border-2 border-white/10 focus:border-blue-500 focus:bg-white/10 rounded-[2.2rem] py-8 pl-16 pr-8 text-5xl font-black text-white outline-none transition-all placeholder:text-white/5 placeholder:font-black tracking-tighter"
                      value={paidAmount}
                      onChange={(e) => { setPaidAmount(e.target.value); beepService.playSoftBeep(); }}
                   />
                   <span className="absolute right-8 top-1/2 -translate-y-1/2 text-[10px] font-black bg-blue-600 text-white px-3 py-1 rounded-full shadow-lg">F2</span>
                </div>

                <div className={`flex justify-between items-center px-8 py-5 rounded-[1.8rem] border-2 transition-all duration-500 ${changeToReturn > 0 ? 'bg-green-500/10 border-green-500/30' : 'bg-white/5 border-transparent'}`}>
                   <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${changeToReturn > 0 ? 'text-green-400' : 'text-white/20'}`}>Change Return</span>
                   <span className={`text-3xl font-black tracking-tighter ${changeToReturn > 0 ? 'text-green-400' : 'text-white/10'}`}>৳{changeToReturn.toFixed(0)}</span>
                </div>

                <button 
                  onClick={confirmTransaction}
                  disabled={!isPaymentValid}
                  className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-white/5 disabled:text-white/5 text-white font-black py-7 rounded-[2.2rem] text-2xl shadow-2xl shadow-blue-600/20 transition-all flex items-center justify-center gap-5 active:scale-95 group uppercase"
                >
                  <i className="fa-solid fa-print text-2xl group-hover:scale-125 transition-transform"></i>
                  <span className="tracking-[0.1em]">Confirm Sale [F12]</span>
                </button>
             </div>
          </div>
        </aside>
      </div>

      {/* Quick Add Customer Modal */}
      {isAddingCustomer && (
        <div className="fixed inset-0 bg-gray-900/80 backdrop-blur-md z-[150] flex items-center justify-center p-6">
          <div className="bg-white rounded-[3.5rem] shadow-2xl max-w-md w-full p-10 animate-in zoom-in-95 duration-200 border border-white/20">
            <div className="flex justify-between items-center mb-10">
               <div>
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">নতুন কাস্টমার</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Quick Customer Registration</p>
               </div>
               <button onClick={() => setIsAddingCustomer(false)} className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center text-gray-400 hover:text-red-500 transition-all">
                  <i className="fa-solid fa-xmark text-lg"></i>
               </button>
            </div>
            
            <form onSubmit={handleQuickAddCustomer} className="space-y-6">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">কাস্টমারের নাম</label>
                <input 
                  type="text" 
                  autoFocus
                  required 
                  className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold shadow-sm transition-all"
                  value={newCustomer.name} 
                  onChange={e => setNewCustomer({...newCustomer, name: e.target.value})} 
                  placeholder="যেমন: রহিম সাহেব"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">মোবাইল নাম্বার</label>
                <input 
                  type="tel" 
                  required 
                  className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold shadow-sm transition-all"
                  value={newCustomer.mobile} 
                  onChange={e => setNewCustomer({...newCustomer, mobile: e.target.value})} 
                  placeholder="01XXXXXXXXX"
                />
              </div>
              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setIsAddingCustomer(false)} className="flex-1 bg-gray-100 text-gray-400 font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all">বাতিল</button>
                <button type="submit" className="flex-2 bg-blue-600 text-white font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all">সেভ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {lastSale && <ReceiptModal sale={lastSale} onClose={() => setLastSale(null)} />}
    </div>
  );
};

export default POSView;
