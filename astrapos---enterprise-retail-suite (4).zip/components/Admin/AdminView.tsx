
import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../store';
import { Product, SystemSettings, Customer, Expense, Sale } from '../../types';
import { generateProductImage } from '../../services/geminiService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AdminViewProps {
  onGoPOS: () => void;
}

const AdminView: React.FC<AdminViewProps> = ({ onGoPOS }) => {
  const { products, sales, addProduct, updateProduct, deleteProduct, settings, updateSettings, customers, addCustomer, expenses, addExpense, deleteExpense } = useApp();
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'INVENTORY' | 'ORDERS' | 'CUSTOMERS' | 'EXPENSES' | 'SETTINGS'>('DASHBOARD');
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [addingCustomer, setAddingCustomer] = useState(false);
  const [addingExpense, setAddingExpense] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [localSettings, setLocalSettings] = useState<SystemSettings>(settings);
  const [showSaveMsg, setShowSaveMsg] = useState(false);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  // Forms
  const [newCustomer, setNewCustomer] = useState({ name: '', mobile: '' });
  const [newExpense, setNewExpense] = useState({ description: '', amount: 0, type: 'OTHER' as any });

  useEffect(() => { setLocalSettings(settings); }, [settings]);

  // Financial Stats
  const stats = useMemo(() => {
    const now = new Date();
    const today = now.toDateString();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const calculateSaleProfit = (s: Sale) => {
      const itemsCost = s.items.reduce((sum, item) => sum + (item.costPrice * item.quantity), 0);
      return s.total - itemsCost - (s.vat || 0);
    };

    const dailySales = sales.filter(s => new Date(s.timestamp).toDateString() === today);
    const monthlySales = sales.filter(s => {
      const d = new Date(s.timestamp);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
    const yearlySales = sales.filter(s => new Date(s.timestamp).getFullYear() === currentYear);

    const dailyRev = dailySales.reduce((sum, s) => sum + s.total, 0);
    const dailyProfit = dailySales.reduce((sum, s) => sum + calculateSaleProfit(s), 0);
    const monthlyRev = monthlySales.reduce((sum, s) => sum + s.total, 0);
    const yearlyRev = yearlySales.reduce((sum, s) => sum + s.total, 0);

    const monthlyProfit = monthlySales.reduce((sum, s) => sum + calculateSaleProfit(s), 0);
    const yearlyProfit = yearlySales.reduce((sum, s) => sum + calculateSaleProfit(s), 0);

    const totalExpenseValue = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const netProfit = yearlyProfit - totalExpenseValue;

    return { dailyRev, dailyProfit, monthlyRev, yearlyRev, monthlyProfit, yearlyProfit, totalExpenseValue, netProfit };
  }, [sales, expenses]);

  const chartData = useMemo(() => {
    const last7Days = [...Array(7)].map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const daySales = sales.filter(s => new Date(s.timestamp).toDateString() === d.toDateString());
      return {
        name: d.toLocaleDateString('en-US', { weekday: 'short' }),
        sales: daySales.reduce((sum, s) => sum + s.total, 0),
      };
    });
    return last7Days;
  }, [sales]);

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    const pData: Product = {
      id: editingProduct.id || Date.now().toString(),
      name: editingProduct.name || 'Untitled',
      category: editingProduct.category || 'General',
      costPrice: Number(editingProduct.costPrice) || 0,
      sellingPrice: Number(editingProduct.sellingPrice) || 0,
      stockQuantity: Number(editingProduct.stockQuantity) || 0,
      lowStockLevel: Number(editingProduct.lowStockLevel) || 5,
      barcode: editingProduct.barcode || String(Date.now()).substr(-8),
      image: editingProduct.image || 'https://via.placeholder.com/150'
    };
    editingProduct.id ? updateProduct(pData) : addProduct(pData);
    setEditingProduct(null);
  };

  const handleSaveSettings = () => {
    updateSettings(localSettings);
    setShowSaveMsg(true);
    setTimeout(() => setShowSaveMsg(false), 3000);
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {showSaveMsg && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 bg-green-600 text-white px-8 py-3 rounded-full shadow-2xl z-[200] font-bold animate-bounce flex items-center gap-3">
          <i className="fa-solid fa-circle-check"></i> সেটিংস সফলভাবে সেভ হয়েছে!
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-72 bg-[#0f172a] text-white flex flex-col p-6 shadow-2xl">
        <div className="flex items-center gap-4 mb-10 px-2">
          <div className="bg-blue-600 w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg"><i className="fa-solid fa-gauge-high text-xl"></i></div>
          <div><span className="font-black text-lg block leading-none">AstraPOS</span><span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Admin Control</span></div>
        </div>
        
        <nav className="flex-1 space-y-2">
          {[
            { id: 'DASHBOARD', icon: 'fa-chart-line', label: 'Dashboard' },
            { id: 'INVENTORY', icon: 'fa-boxes-stacked', label: 'Inventory' },
            { id: 'ORDERS', icon: 'fa-receipt', label: 'Order History' },
            { id: 'CUSTOMERS', icon: 'fa-users', label: 'Customers' },
            { id: 'EXPENSES', icon: 'fa-wallet', label: 'Expenses' },
            { id: 'SETTINGS', icon: 'fa-gears', label: 'Store Settings' },
          ].map((tab) => (
            <button 
              key={tab.id} 
              onClick={() => setActiveTab(tab.id as any)} 
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-[11px] font-black tracking-widest transition-all uppercase ${activeTab === tab.id ? 'bg-blue-600 text-white shadow-xl shadow-blue-900/60' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
              <i className={`fa-solid ${tab.icon} w-5`}></i> {tab.label}
            </button>
          ))}
        </nav>

        <button onClick={onGoPOS} className="mt-auto bg-gray-800 hover:bg-red-500/20 text-white font-black py-4 rounded-2xl transition-all flex items-center justify-center gap-3 text-[10px] uppercase tracking-widest">
          <i className="fa-solid fa-arrow-left"></i> Open POS Terminal
        </button>
      </aside>

      {/* Main View */}
      <main className="flex-1 overflow-y-auto p-10 bg-gray-50/50">
        {activeTab === 'DASHBOARD' && (
          <div className="space-y-10 animate-in fade-in duration-500">
            <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Financial Analytics</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
                <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Today Sales</p>
                <p className="text-3xl font-black text-blue-600 mt-2">৳{stats.dailyRev.toFixed(0)}</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
                <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Today Profit</p>
                <p className="text-3xl font-black text-emerald-600 mt-2">৳{stats.dailyProfit.toFixed(0)}</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
                <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Monthly Profit</p>
                <p className="text-3xl font-black text-green-600 mt-2">৳{stats.monthlyProfit.toFixed(0)}</p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
                <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Yearly Profit</p>
                <p className="text-3xl font-black text-purple-600 mt-2">৳{stats.yearlyProfit.toFixed(0)}</p>
              </div>
              <div className="bg-[#0f172a] p-8 rounded-[2.5rem] shadow-xl text-white">
                <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Net Health</p>
                <p className="text-3xl font-black text-blue-400 mt-2">৳{stats.netProfit.toFixed(0)}</p>
                <p className="text-[8px] opacity-40 font-bold mt-1">(Annual Profit - Expenses)</p>
              </div>
            </div>

            <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100">
              <h3 className="font-black text-gray-800 uppercase tracking-widest text-xs mb-8">Weekly Sales Growth</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900}} />
                    <Tooltip contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                    <Area type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={4} fillOpacity={0.1} fill="#3b82f6" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'INVENTORY' && (
          <div className="space-y-6">
            <div className="flex justify-between items-end mb-8">
              <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Inventory Control</h2>
              <button onClick={() => setEditingProduct({})} className="bg-blue-600 text-white font-black px-8 py-4 rounded-2xl shadow-xl shadow-blue-500/20 text-[10px] uppercase tracking-widest flex items-center gap-3 active:scale-95 transition-all">
                <i className="fa-solid fa-plus"></i> Add New Product
              </button>
            </div>
            <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-gray-50/50 text-gray-400 text-[10px] font-black uppercase tracking-widest border-b">
                  <tr><th className="px-8 py-6">Product Details</th><th className="px-8 py-6">Barcode</th><th className="px-8 py-6">Cost</th><th className="px-8 py-6">Selling</th><th className="px-8 py-6">Stock</th><th className="px-8 py-6 text-right">Actions</th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {products.map(p => (
                    <tr key={p.id} className="hover:bg-gray-50/30 transition-colors">
                      <td className="px-8 py-5 flex items-center gap-4">
                        <img src={p.image || 'https://via.placeholder.com/150'} className="w-12 h-12 rounded-xl object-cover bg-gray-100 border" />
                        <div><p className="font-bold text-gray-900 text-sm">{p.name}</p><p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{p.category}</p></div>
                      </td>
                      <td className="px-8 py-5 font-mono text-xs text-gray-400 font-black">{p.barcode}</td>
                      <td className="px-8 py-5 font-bold text-gray-500">৳{p.costPrice}</td>
                      <td className="px-8 py-5 font-black text-gray-900">৳{p.sellingPrice}</td>
                      <td className="px-8 py-5"><span className={`text-xs font-black uppercase tracking-widest ${p.stockQuantity <= p.lowStockLevel ? 'text-red-500' : 'text-green-500'}`}>{p.stockQuantity} Units</span></td>
                      <td className="px-8 py-5 text-right">
                        <div className="flex justify-end gap-3">
                          <button onClick={() => setEditingProduct(p)} className="w-10 h-10 flex items-center justify-center text-blue-500 bg-blue-50 hover:bg-blue-600 hover:text-white rounded-xl transition-all"><i className="fa-solid fa-pen text-xs"></i></button>
                          <button onClick={() => {if(confirm("প্রোডাক্ট ডিলিট করতে চান?")) deleteProduct(p.id)}} className="w-10 h-10 flex items-center justify-center text-red-400 bg-red-50 hover:bg-red-500 hover:text-white rounded-xl transition-all"><i className="fa-solid fa-trash text-xs"></i></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'ORDERS' && (
          <div className="space-y-8">
            <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Order History</h2>
            <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead className="bg-gray-50/50 text-[10px] font-black uppercase tracking-widest border-b">
                  <tr>
                    <th className="px-8 py-6">Invoice</th>
                    <th className="px-8 py-6">Date</th>
                    <th className="px-8 py-6">Customer</th>
                    <th className="px-8 py-6 text-right">Total</th>
                    <th className="px-8 py-6 text-right w-32">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {sales.slice().reverse().map(s => (
                    <React.Fragment key={s.id}>
                      <tr className={`${expandedOrder === s.id ? 'bg-blue-50/30' : ''} transition-colors`}>
                        <td className="px-8 py-5 font-mono font-black text-blue-600 text-xs">{s.id}</td>
                        <td className="px-8 py-5 text-xs text-gray-500 font-bold">{new Date(s.timestamp).toLocaleString()}</td>
                        <td className="px-8 py-5 font-black text-gray-800 text-xs">{s.customerId || 'Walk-in'}</td>
                        <td className="px-8 py-5 text-right font-black text-gray-900">৳{s.total.toFixed(0)}</td>
                        <td className="px-8 py-5 text-right">
                          <button 
                            onClick={() => setExpandedOrder(expandedOrder === s.id ? null : s.id)}
                            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${expandedOrder === s.id ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400 hover:bg-blue-100 hover:text-blue-600'}`}
                          >
                            <i className={`fa-solid ${expandedOrder === s.id ? 'fa-chevron-up' : 'fa-eye'} text-[10px]`}></i>
                          </button>
                        </td>
                      </tr>
                      {expandedOrder === s.id && (
                        <tr>
                          <td colSpan={5} className="bg-gray-50/50 p-0 border-b border-blue-100/50">
                            <div className="p-8 animate-in slide-in-from-top-4 duration-300">
                              <div className="flex items-center gap-3 mb-6 px-1">
                                <div className="w-1 h-6 bg-blue-600 rounded-full"></div>
                                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Items Purchased</h4>
                              </div>
                              <div className="bg-white rounded-3xl border border-blue-100/50 overflow-hidden shadow-sm">
                                <table className="w-full text-left text-[11px]">
                                  <thead className="bg-blue-50/20 border-b border-blue-100/30">
                                    <tr>
                                      <th className="px-6 py-4 font-black text-blue-600/60 uppercase tracking-widest">Product</th>
                                      <th className="px-6 py-4 font-black text-blue-600/60 uppercase tracking-widest text-center">Qty</th>
                                      <th className="px-6 py-4 font-black text-blue-600/60 uppercase tracking-widest text-right">Unit Price</th>
                                      <th className="px-6 py-4 font-black text-blue-600/60 uppercase tracking-widest text-right">Subtotal</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-50">
                                    {s.items.map(item => (
                                      <tr key={item.id}>
                                        <td className="px-6 py-4 font-bold text-gray-700">{item.name}</td>
                                        <td className="px-6 py-4 text-center font-black text-gray-400">x{item.quantity}</td>
                                        <td className="px-6 py-4 text-right font-bold text-gray-500">৳{item.sellingPrice.toFixed(0)}</td>
                                        <td className="px-6 py-4 text-right font-black text-gray-900">৳{(item.sellingPrice * item.quantity).toFixed(0)}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                  <tfoot className="bg-gray-50/50 border-t border-gray-100">
                                    <tr className="font-black">
                                      <td colSpan={3} className="px-6 py-4 text-right text-gray-400 uppercase tracking-widest">Subtotal</td>
                                      <td className="px-6 py-4 text-right text-gray-700">৳{s.subtotal.toFixed(0)}</td>
                                    </tr>
                                    {s.vat > 0 && (
                                      <tr className="font-black">
                                        <td colSpan={3} className="px-6 py-4 text-right text-gray-400 uppercase tracking-widest">VAT</td>
                                        <td className="px-6 py-4 text-right text-gray-700">৳{s.vat.toFixed(0)}</td>
                                      </tr>
                                    )}
                                    <tr className="font-black bg-blue-50/20">
                                      <td colSpan={3} className="px-6 py-4 text-right text-blue-600 uppercase tracking-widest">Grand Total</td>
                                      <td className="px-6 py-4 text-right text-blue-600 text-sm">৳{s.total.toFixed(0)}</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'CUSTOMERS' && (
          <div className="space-y-8">
            <div className="flex justify-between items-end">
              <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Customer CRM</h2>
              <button onClick={() => setAddingCustomer(true)} className="bg-blue-600 text-white font-black px-8 py-4 rounded-2xl shadow-xl text-[10px] uppercase tracking-widest flex items-center gap-3 active:scale-95">
                <i className="fa-solid fa-user-plus"></i> New Customer
              </button>
            </div>
            <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-gray-50/50 text-[10px] font-black uppercase tracking-widest border-b">
                  <tr><th className="px-8 py-6">Name</th><th className="px-8 py-6">Mobile</th><th className="px-8 py-6 text-right">Lifetime Spent</th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {customers.map(c => {
                    const spent = sales.filter(s => s.customerId === c.name).reduce((sum, s) => sum + s.total, 0);
                    return (
                      <tr key={c.id}>
                        <td className="px-8 py-5 font-black text-gray-800">{c.name}</td>
                        <td className="px-8 py-5 font-mono text-xs text-gray-500">{c.mobile}</td>
                        <td className="px-8 py-5 text-right font-black text-green-600">৳{spent.toFixed(0)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'EXPENSES' && (
          <div className="space-y-8">
            <div className="flex justify-between items-end">
              <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Expense Records</h2>
              <button onClick={() => setAddingExpense(true)} className="bg-red-500 text-white font-black px-8 py-4 rounded-2xl shadow-xl text-[10px] uppercase tracking-widest flex items-center gap-3 active:scale-95">
                <i className="fa-solid fa-file-invoice-dollar"></i> New Expense
              </button>
            </div>
            <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-gray-50/50 text-[10px] font-black uppercase tracking-widest border-b">
                  <tr><th className="px-8 py-6">Description</th><th className="px-8 py-6">Category</th><th className="px-8 py-6">Date</th><th className="px-8 py-6 text-right">Amount</th><th className="px-8 py-6"></th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {expenses.slice().reverse().map(e => (
                    <tr key={e.id}>
                      <td className="px-8 py-5 font-bold text-gray-800 text-xs">{e.description}</td>
                      <td className="px-8 py-5"><span className="bg-gray-100 px-3 py-1 rounded-full text-[8px] font-black uppercase">{e.type}</span></td>
                      <td className="px-8 py-5 text-xs text-gray-400 font-bold">{new Date(e.date).toDateString()}</td>
                      <td className="px-8 py-5 text-right font-black text-red-600">৳{e.amount}</td>
                      <td className="px-8 py-5 text-right"><button onClick={() => deleteExpense(e.id)} className="text-gray-300 hover:text-red-500"><i className="fa-solid fa-trash-can"></i></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'SETTINGS' && (
          <div className="max-w-3xl space-y-8 animate-in fade-in duration-500">
            <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Business Config</h2>
            <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100 space-y-10">
              <div className="grid grid-cols-2 gap-8">
                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Shop Name</label>
                  <input type="text" value={localSettings.shopName} onChange={(e) => setLocalSettings({...localSettings, shopName: e.target.value})} className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold text-sm shadow-sm" />
                </div>
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Phone</label><input type="text" value={localSettings.phone} onChange={(e) => setLocalSettings({...localSettings, phone: e.target.value})} className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold text-sm shadow-sm" /></div>
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Address</label><input type="text" value={localSettings.address} onChange={(e) => setLocalSettings({...localSettings, address: e.target.value})} className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold text-sm shadow-sm" /></div>
              </div>
              <div className="pt-6 border-t space-y-6">
                <div className="flex items-center justify-between p-6 bg-gray-50 rounded-[2rem] border">
                  <div><p className="font-bold text-gray-800 text-sm">VAT Calculation</p><p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Automatic tax addition</p></div>
                  <button onClick={() => setLocalSettings({...localSettings, vatEnabled: !localSettings.vatEnabled})} className={`w-14 h-8 rounded-full relative transition-all ${localSettings.vatEnabled ? 'bg-blue-600' : 'bg-gray-200'}`}><div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all ${localSettings.vatEnabled ? 'left-7' : 'left-1'}`}></div></button>
                </div>
                {localSettings.vatEnabled && (
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">VAT Percentage (%)</label><input type="number" value={localSettings.vatPercentage} onChange={(e) => setLocalSettings({...localSettings, vatPercentage: Number(e.target.value)})} className="w-full max-w-[200px] bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-5 px-6 outline-none font-bold text-sm shadow-sm" /></div>
                )}
              </div>
              <button onClick={handleSaveSettings} className="w-full bg-[#0f172a] hover:bg-blue-600 text-white font-black py-6 rounded-[2rem] text-[10px] uppercase tracking-widest transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-4">
                <i className="fa-solid fa-floppy-disk"></i> Save Configuration
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Product Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-[3.5rem] shadow-2xl max-w-2xl w-full overflow-hidden border border-white/20">
            <div className="p-8 border-b flex justify-between items-center bg-gray-50/30">
              <h3 className="text-lg font-black text-gray-900 uppercase tracking-tight">{editingProduct.id ? 'Edit Product' : 'New Product'}</h3>
              <button onClick={() => setEditingProduct(null)} className="w-12 h-12 rounded-full bg-white border flex items-center justify-center text-gray-400 hover:text-red-500 transition-all active:scale-90"><i className="fa-solid fa-xmark text-lg"></i></button>
            </div>
            <form onSubmit={handleSaveProduct} className="p-10 space-y-6">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Product Name</label>
                <div className="flex gap-3">
                  <input type="text" required className="flex-1 bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold text-sm" value={editingProduct.name || ''} onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})} placeholder="e.g. Rice 10KG" />
                  <button type="button" onClick={async () => { if(!editingProduct.name) return; setAiLoading(true); const url = await generateProductImage(editingProduct.name); if(url) setEditingProduct(p => ({...p, image: url})); setAiLoading(false); }} disabled={!editingProduct.name || aiLoading} className="bg-purple-600 text-white font-black px-6 rounded-2xl text-[10px] flex items-center gap-3 transition-all active:scale-95 uppercase tracking-widest">{aiLoading ? <i className="fa-solid fa-sync fa-spin"></i> : <i className="fa-solid fa-wand-magic-sparkles"></i>} AI Image</button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Cost Price (৳)</label><input type="number" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold text-sm" value={editingProduct.costPrice || ''} onChange={(e) => setEditingProduct({...editingProduct, costPrice: Number(e.target.value)})} /></div>
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Selling Price (৳)</label><input type="number" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold text-sm" value={editingProduct.sellingPrice || ''} onChange={(e) => setEditingProduct({...editingProduct, sellingPrice: Number(e.target.value)})} /></div>
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Barcode</label><input type="text" className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold text-sm tracking-widest" value={editingProduct.barcode || ''} onChange={(e) => setEditingProduct({...editingProduct, barcode: e.target.value})} /></div>
                <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Stock Qty</label><input type="number" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold text-sm" value={editingProduct.stockQuantity || ''} onChange={(e) => setEditingProduct({...editingProduct, stockQuantity: Number(e.target.value)})} /></div>
              </div>
              <div className="mt-8 flex gap-4">
                <button type="button" onClick={() => setEditingProduct(null)} className="flex-1 bg-gray-100 text-gray-400 font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest shadow-2xl active:scale-95 transition-all">Save Product</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Modal */}
      {addingCustomer && (
        <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-[3.5rem] shadow-2xl max-w-md w-full p-10">
            <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter mb-8">New Customer</h3>
            <form onSubmit={(e) => { e.preventDefault(); addCustomer({ id: Date.now().toString(), ...newCustomer }); setNewCustomer({name:'', mobile:''}); setAddingCustomer(false); }} className="space-y-6">
              <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Name</label><input type="text" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold" value={newCustomer.name} onChange={e => setNewCustomer({...newCustomer, name: e.target.value})} /></div>
              <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Mobile</label><input type="tel" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold" value={newCustomer.mobile} onChange={e => setNewCustomer({...newCustomer, mobile: e.target.value})} /></div>
              <div className="flex gap-4 pt-4"><button type="button" onClick={() => setAddingCustomer(false)} className="flex-1 bg-gray-100 text-gray-400 font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest">Cancel</button><button type="submit" className="flex-1 bg-blue-600 text-white font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest shadow-xl">Add Customer</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      {addingExpense && (
        <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-[3.5rem] shadow-2xl max-w-md w-full p-10">
            <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter mb-8">Record Expense</h3>
            <form onSubmit={(e) => { e.preventDefault(); addExpense({ id: Date.now().toString(), date: new Date().toISOString(), ...newExpense }); setNewExpense({description:'', amount:0, type:'OTHER'}); setAddingExpense(false); }} className="space-y-6">
              <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Description</label><input type="text" required placeholder="e.g. Current Bill" className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold" value={newExpense.description} onChange={e => setNewExpense({...newExpense, description: e.target.value})} /></div>
              <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Category</label><select className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold" value={newExpense.type} onChange={e => setNewExpense({...newExpense, type: e.target.value as any})}><option value="UTILITY">Utility / Current Bill</option><option value="STAFF">Staff Salary</option><option value="OTHER">Other Expenses</option></select></div>
              <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Amount (৳)</label><input type="number" required className="w-full bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl py-4 px-6 outline-none font-bold" value={newExpense.amount || ''} onChange={e => setNewExpense({...newExpense, amount: Number(e.target.value)})} /></div>
              <div className="flex gap-4 pt-4"><button type="button" onClick={() => setAddingExpense(false)} className="flex-1 bg-gray-100 text-gray-400 font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest">Cancel</button><button type="submit" className="flex-1 bg-red-500 text-white font-black py-5 rounded-[2rem] text-[10px] uppercase tracking-widest shadow-xl">Save Expense</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
