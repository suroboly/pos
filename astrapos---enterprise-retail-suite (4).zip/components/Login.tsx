
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole } from '../types';

interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { setCurrentUser } = useApp();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulated auth logic
    if (username === 'admin' && password === 'admin') {
      setCurrentUser({ id: '1', name: 'Master Admin', username: 'admin', role: UserRole.ADMIN });
      onLoginSuccess();
    } else if (username === 'staff' && password === 'staff') {
      setCurrentUser({ id: '2', name: 'Sales Associate', username: 'staff', role: UserRole.STAFF });
      onLoginSuccess();
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-10 transform transition-all">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-full mb-4">
            <i className="fa-solid fa-cash-register text-3xl text-white"></i>
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">AstraPOS</h1>
          <p className="text-gray-500 mt-2">Sign in to your station</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              placeholder="Enter username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200 shadow-lg"
          >
            Access System
          </button>
        </form>
        
        <div className="mt-8 text-center text-xs text-gray-400">
          <p>&copy; 2024 Astra Systems. All rights reserved.</p>
          <p className="mt-1">Offline-First Engine v4.2.0</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
