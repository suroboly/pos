
import React, { useState } from 'react';
import { AppProvider, useApp } from './store';
import Login from './components/Login';
import POSView from './components/POS/POSView';
import AdminView from './components/Admin/AdminView';

const AppContent: React.FC = () => {
  const { currentUser } = useApp();
  const [view, setView] = useState<'LOGIN' | 'POS' | 'ADMIN'>('LOGIN');

  if (!currentUser) {
    return <Login onLoginSuccess={() => setView('POS')} />;
  }

  if (view === 'POS') {
    return <POSView onGoAdmin={() => setView('ADMIN')} />;
  }

  if (view === 'ADMIN') {
    return <AdminView onGoPOS={() => setView('POS')} />;
  }

  return <Login onLoginSuccess={() => setView('POS')} />;
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
