
/**
 * Professional scanner beep service using Web Audio API for zero-latency performance.
 */
class BeepService {
  private audioContext: AudioContext | null = null;

  init() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  private play(frequency: number, duration: number, volume: number, type: OscillatorType = 'sine') {
    this.init();
    if (!this.audioContext) return;

    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }

    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(frequency, this.audioContext.currentTime);

    gain.gain.setValueAtTime(volume, this.audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.00001, this.audioContext.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.audioContext.destination);

    osc.start();
    osc.stop(this.audioContext.currentTime + duration);
  }

  /**
   * একদম সফট টাচ বিপ (বাটন ক্লিকের জন্য)
   */
  playSoftBeep() {
    this.play(950, 0.04, 0.1, 'sine');
  }

  /**
   * প্রিমিয়াম শার্প স্ক্যান বিপ (বারকোড স্ক্যানের জন্য)
   */
  playScanSuccess() {
    this.play(1300, 0.05, 0.15, 'sine');
  }

  /**
   * ক্যাশ ড্রয়ার খোলার প্রিমিয়াম মেটালিক সাউন্ড
   */
  playCashDrawerOpen() {
    this.play(150, 0.3, 0.1, 'triangle'); // Slide sound
    setTimeout(() => this.play(2800, 0.08, 0.1, 'sine'), 40); // Soft Ding!
  }

  playError() {
    this.play(200, 0.3, 0.2, 'sawtooth');
  }

  playPaymentSuccess() {
    this.play(1100, 0.08, 0.15);
    setTimeout(() => this.play(1600, 0.1, 0.15), 50);
  }

  playRemove() {
    this.play(400, 0.1, 0.1, 'sine');
  }
}

export const beepService = new BeepService();
